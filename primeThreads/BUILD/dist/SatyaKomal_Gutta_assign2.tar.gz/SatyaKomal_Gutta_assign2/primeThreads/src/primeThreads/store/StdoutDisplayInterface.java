
package primeThreads.store;

import java.util.Vector;

public interface StdoutDisplayInterface {
	public void writeSumToScreen();
	public void addNum(int In);
	public void printVector();
	public Vector<Integer> getV();
}
